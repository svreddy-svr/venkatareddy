import numpy as np

arr = np.zeros((5, 10), dtype=int)

print(arr)
print("Array attributes:")
print("Shape:", arr.shape)
print("Dimensions:", arr.ndim)
print("Size:", arr.size)
print("Data type:", arr.dtype)
