import numpy as np

arr = np.full((3, 4), 7)

print(arr)