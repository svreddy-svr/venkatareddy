import numpy as np

arr = np.array([10, 20, 30, 40])
print(arr[0])
print(arr[-1])
print()

arr2d = np.array([[1, 2, 3],
                  [4, 5, 7],
                  [7, 8, 9]])
print(arr2d[0, 1])
print(arr2d[2, -1])
