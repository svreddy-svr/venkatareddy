import numpy as np

arr1 = np.linspace(0, 10, 5)
print(arr1)
arr2 = np.linspace(-50, 50, 11)
print(arr2)
