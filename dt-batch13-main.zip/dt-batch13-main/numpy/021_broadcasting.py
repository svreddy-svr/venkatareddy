import numpy as np

arr1 = np.array([[1, 2, 3],
                 [4, 5, 6]])

arr2 = np.array([10, 20, 30])
print(arr1 + arr2)  # Broadcasting addition