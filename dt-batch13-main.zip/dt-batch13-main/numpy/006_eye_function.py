import numpy as np

arr = np.eye(5, dtype=int)
print(arr)