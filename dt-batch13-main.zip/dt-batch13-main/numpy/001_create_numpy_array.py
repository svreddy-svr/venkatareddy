import numpy as np

## one-dimensional array
arr = np.array([1, 2, 3, 4, 5])
print("Arr type:", type(arr))
print()
print("Arr:", arr)

## two-dimensional array
arr2D = np.array([[11, 12, 13],
          [14, 15, 16]])

print(arr2D)
