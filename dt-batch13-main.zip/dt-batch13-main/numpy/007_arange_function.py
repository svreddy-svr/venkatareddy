import numpy as np

arr1 = np.arange(5)
arr2 = np.arange(10, 20, 2)
print("Array 1:", arr1)
print("Array 2:", arr2)