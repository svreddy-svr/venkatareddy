import numpy as np

arr1 = np.random.rand(2, 3)
print(arr1)

arr2 = np.random.randn(3, 2)
print(arr2)

arr3 = np.random.randint(0, 10, size=(4, 5))
print(arr3)