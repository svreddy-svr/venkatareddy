import numpy as np

arr = np.array([1.2, 3.4, 5.6, 7.8])
arr_int = arr.astype(int)
print("Converted array:", arr_int)